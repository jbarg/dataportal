#!/bin/bash

$JAVA_HOME/bin/java -jar lib/Proxy.jar
