Data Portal MyProxy server application
========================================

This application is used to put your Globus Credentials into a MyProxy Server.

Runnning
--------

Windows

This can be run 2 ways.

1) Execute run.bat
2) Execute lib/Proxy.jar (windows can execute a .jar file as if it was a .exe file)

Unix

1) Execute run.sh

